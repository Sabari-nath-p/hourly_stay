# whatsapp_bot/utils.py
import json
import requests
from django.conf import settings
from .models import WhatsAppContact, WhatsAppMessage

def process_incoming_message(data):
    """Process incoming WhatsApp message and return response data"""
    try:
        # Extract message from WhatsApp payload
        entry = data['entry'][0]
        changes = entry['changes'][0]
        value = changes['value']
        message = value['messages'][0]
        
        # Extract contact info
        sender = message['from']
        
        # Get or create contact
        contact, created = WhatsAppContact.objects.get_or_create(
            phone_number=sender,
            defaults={'active': True}
        )
        
        # Update contact name if available
        if 'contacts' in value and value['contacts']:
            contact_info = value['contacts'][0]
            if 'profile' in contact_info and 'name' in contact_info['profile']:
                contact.name = contact_info['profile']['name']
                contact.save()
        
        # Extract message content
        message_type = message.get('type', 'text')
        if message_type == 'text':
            message_text = message['text']['body']
        else:
            message_text = f"[{message_type} message]"
        
        # Save the message
        WhatsAppMessage.objects.create(
            contact=contact,
            message=message_text,
            is_incoming=True,
            message_type=message_type
        )
        
        return {
            'contact': contact,
            'message': message_text,
            'type': message_type
        }
    except Exception as e:
        print(f"Error processing message: {e}")
        return None

def send_whatsapp_message(phone_number, message, message_type='text'):
    """Send WhatsApp message and save to database"""
    headers = {
        'Authorization': f'Bearer {settings.WHATSAPP_TOKEN}',
        'Content-Type': 'application/json',
    }
    
    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": phone_number,
        "type": message_type,
    }
    
    if message_type == 'text':
        payload["text"] = {"body": message}
    # Add support for other message types (images, documents, etc.)
    
    url = f"https://graph.facebook.com/v21.0/{settings.PHONE_NUMBER_ID}/messages"
    
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        # Save the outgoing message
        contact = WhatsAppContact.objects.get(phone_number=phone_number)
        WhatsAppMessage.objects.create(
            contact=contact,
            message=message,
            is_incoming=False,
            message_type=message_type,
            status='sent'
        )
        
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error sending WhatsApp message: {e}")
        return None

def generate_response(message_data):
    """Generate automated response based on incoming message"""
    if not message_data:
        return None
        
    message_text = message_data['message'].lower()
    contact = message_data['contact']
    
    # Basic response logic - customize this based on your needs
    if 'hello' in message_text or 'hi' in message_text:
        response = f"Hello {contact.name or 'there'}! How can I help you today?"
    elif 'bye' in message_text:
        response = "Goodbye! Have a great day!"
    elif 'help' in message_text:
        response = "I'm here to help! You can ask me about:\n- Our products\n- Services\n- Business hours\n- Contact information"
    else:
        response = f"Thank you for your message: {message_text}\nI'll process this and get back to you soon."
    
    return response
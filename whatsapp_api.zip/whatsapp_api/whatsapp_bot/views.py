# whatsapp_bot/views.py
import json
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from .models import WhatsAppContact, WhatsAppMessage
from .utils import send_whatsapp_message

@csrf_exempt
def webhook(request):
    if request.method == 'GET':
        # Handle webhook verification
        mode = request.GET.get('hub.mode')
        token = request.GET.get('hub.verify_token')
        challenge = request.GET.get('hub.challenge')

        if mode and token:
            if mode == 'subscribe' and token == settings.VERIFY_TOKEN:
                return HttpResponse(challenge, content_type='text/plain')
            return HttpResponse('Forbidden', status=403)

    elif request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
            
            if 'entry' in data and data['entry']:
                entry = data['entry'][0]
                if 'changes' in entry and entry['changes']:
                    change = entry['changes'][0]
                    if 'value' in change and 'messages' in change['value']:
                        message = change['value']['messages'][0]
                        
                        # Extract message details
                        phone_number = message['from']
                        message_text = message['text']['body']
                        
                        # Get or create contact
                        contact, created = WhatsAppContact.objects.get_or_create(
                            phone_number=phone_number,
                            defaults={'active': True}
                        )
                        
                        # Save message
                        WhatsAppMessage.objects.create(
                            contact=contact,
                            message=message_text,
                            is_incoming=True,
                            message_type='text',
                            status='received'
                        )
                        
                        # Generate and send reply
                        reply_message = f"Thanks for your message: {message_text}"
                        send_whatsapp_message(phone_number, reply_message)
            
            return JsonResponse({'status': 'success'})
            
        except Exception as e:
            print(f"Error processing webhook: {e}")
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

    return HttpResponse('Method not allowed', status=405)
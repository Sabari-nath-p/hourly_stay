#  whatsapp_bot/models.py
from django.db import models

class WhatsAppContact(models.Model):
    phone_number = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_message_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name or 'Unknown'} ({self.phone_number})"

class WhatsAppMessage(models.Model):
    contact = models.ForeignKey(WhatsAppContact, on_delete=models.CASCADE)
    message = models.TextField()
    is_incoming = models.BooleanField(default=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    message_type = models.CharField(max_length=20, default='text')  # text, image, video, etc.
    status = models.CharField(max_length=20, default='received')  # received, sent, failed

    def __str__(self):
        direction = "from" if self.is_incoming else "to"
        return f"Message {direction} {self.contact.phone_number}: {self.message[:50]}"